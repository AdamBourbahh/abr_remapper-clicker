#pragma once

#include "Common.h"

// --- Key Utility Functions ---
wstring GetKeyNameFromVkCode(DWORD vkCode);
DWORD ShowKeySelectionWindow(HWND parentWindow, bool isOrigin);
LRESULT CALLBACK KeySelectWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);