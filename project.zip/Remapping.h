#pragma once

#include "Common.h"

// --- Remapping Functions ---
void UpdateRemapList(HWND hListCtrl);
void LoadRemapConfig();
void SaveRemapConfig();
LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam);