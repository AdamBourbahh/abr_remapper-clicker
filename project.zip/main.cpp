#include "Common.h"
#include "Language.h"
#include "Remapping.h"
#include "WindowProc.h"

/// @brief Punto de entrada de la aplicaci�n WinAPI.
/// @return El c�digo de salida de la aplicaci�n.
int WINAPI WinMain(_In_ HINSTANCE hInstance, _In_opt_ HINSTANCE hPrevInstance, _In_ LPSTR lpCmdLine, _In_ int nCmdShow) {
    // Carga la preferencia de idioma
    LoadLanguagePreference();

    // 1. Registra la clase de la ventana, como si dieras de alta un nuevo tipo de veh�culo.
    WNDCLASSEX wc = { 0 };
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = L"RemapAppClass";

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, L"Failed to register window class.", L"Error", MB_ICONERROR);
        return 1;
    }

    // 2. Crea la ventana principal. �Tu interfaz cobra vida!
    g_hMainWindow = CreateWindowEx(
        0,                             // Estilos extendidos.
        L"RemapAppClass",              // Nombre de la clase registrada.
        g_strings[g_currentLanguage].windowTitle.c_str(), // T�tulo de la ventana.
        WS_OVERLAPPEDWINDOW | WS_VSCROLL, // Estilo est�ndar de ventana con scroll.
        CW_USEDEFAULT, CW_USEDEFAULT,  // Posici�n por defecto.
        450, 550,                      // Tama�o (ancho, alto).
        NULL,                          // Sin ventana padre.
        NULL,                          // Sin men�.
        hInstance,                     // Handle de la instancia de la aplicaci�n.
        NULL
    );

    if (!g_hMainWindow) {
        MessageBox(NULL, L"Failed to create main window.", L"Error", MB_ICONERROR);
        return 1;
    }

    // 3. Carga la configuraci�n de remapeo al inicio. �Para que no se te olvide nada!
    LoadRemapConfig();

    // 4. Muestra la ventana. �Al fin, el show empieza!
    ShowWindow(g_hMainWindow, nCmdShow);
    UpdateWindow(g_hMainWindow);

    // 5. Si es la primera ejecuci�n, mostrar el di�logo de selecci�n de idioma
    if (g_isFirstRun) {
        g_currentLanguage = ShowLanguageDialog(g_hMainWindow);
        SaveLanguagePreference();
    }

    // 6. Actualiza los textos y asegura que los remapeos se muestren correctamente
    UpdateLanguageTexts();

    // 7. El bucle de mensajes: el latido constante de tu aplicaci�n GUI.
    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    // Desengancha el hook del teclado al salir. �No queremos dejar cabos sueltos!
    if (keyboardHook) {
        UnhookWindowsHookEx(keyboardHook);
        keyboardHook = NULL;
    }

    // Limpieza final
    if (g_hTrayMenu) {
        DestroyMenu(g_hTrayMenu);
    }

    return (int)msg.wParam;
}