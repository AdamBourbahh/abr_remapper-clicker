#include "WindowProc.h"
#include "Language.h"
#include "KeyUtils.h"
#include "Remapping.h"
#include "TrayIcon.h"

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        // Crea los controles GUI al iniciar la ventana.
        g_hButtonActivate = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].activateRemap.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            10, 10, 180, 30,
            hwnd, (HMENU)IDC_BUTTON_ACTIVATE_REMAP, GetModuleHandle(NULL), NULL
        );

        // Controles de la tecla Origen.
        CreateWindow(L"STATIC", g_strings[g_currentLanguage].originKey.c_str(),
            WS_CHILD | WS_VISIBLE, 10, 60, 100, 20, hwnd, NULL, GetModuleHandle(NULL), NULL);
        g_hEditOrigin = CreateWindow(
            L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
            120, 55, 100, 25,
            hwnd, (HMENU)IDC_EDIT_ORIGIN_KEY, GetModuleHandle(NULL), NULL
        );
        g_hButtonSelectOrigin = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].selectOrigin.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            230, 55, 140, 25,
            hwnd, (HMENU)IDC_BUTTON_SELECT_ORIGIN, GetModuleHandle(NULL), NULL
        );

        // Controles de la tecla Destino.
        CreateWindow(L"STATIC", g_strings[g_currentLanguage].destinyKey.c_str(),
            WS_CHILD | WS_VISIBLE, 10, 90, 100, 20, hwnd, NULL, GetModuleHandle(NULL), NULL);
        g_hEditDestiny = CreateWindow(
            L"EDIT", L"",
            WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
            120, 85, 100, 25,
            hwnd, (HMENU)IDC_EDIT_DESTINY_KEY, GetModuleHandle(NULL), NULL
        );
        g_hButtonSelectDestiny = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].selectDestiny.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            230, 85, 140, 25,
            hwnd, (HMENU)IDC_BUTTON_SELECT_DESTINY, GetModuleHandle(NULL), NULL
        );

        // Bot�n para a�adir remapeo.
        g_hButtonAddRemap = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].addRemap.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            10, 130, 150, 30,
            hwnd, (HMENU)IDC_BUTTON_ADD_REMAP, GetModuleHandle(NULL), NULL
        );

        // Bot�n para eliminar remapeo.
        g_hButtonRemoveRemap = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].removeSelected.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            170, 130, 180, 30,
            hwnd, (HMENU)IDC_BUTTON_REMOVE_REMAP, GetModuleHandle(NULL), NULL
        );

        // Etiqueta para la lista de remapeos actuales.
        CreateWindow(L"STATIC", g_strings[g_currentLanguage].activeRemaps.c_str(),
            WS_CHILD | WS_VISIBLE, 10, 170, 150, 20, hwnd, NULL, GetModuleHandle(NULL), NULL);

        // ListBox para mostrar los remapeos.
        g_hListRemapping = CreateWindow(
            L"LISTBOX", NULL,
            WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY | WS_VSCROLL,
            10, 195, 360, 250,
            hwnd, (HMENU)IDC_LIST_REMAPPING, GetModuleHandle(NULL), NULL
        );

        // Etiqueta para el estado. �El chismoso oficial de la app!
        g_hStaticStatus = CreateWindow(
            L"STATIC", g_strings[g_currentLanguage].statusReady.c_str(),
            WS_CHILD | WS_VISIBLE,
            10, 460, 360, 20,
            hwnd, (HMENU)IDC_STATIC_STATUS, GetModuleHandle(NULL), NULL
        );

        // Bot�n para cambiar el idioma
        g_hButtonChangeLanguage = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].changeLanguage.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            200, 10, 180, 30,
            hwnd, (HMENU)IDC_BUTTON_CHANGE_LANGUAGE, GetModuleHandle(NULL), NULL
        );

        // Llena la lista con los remapeos guardados.
        UpdateRemapList(g_hListRemapping);

        break;
    }

    case WM_COMMAND: {
        // Maneja los eventos de los controles (ej. clics en botones).
        int wmId = LOWORD(wParam); // ID del control que envi� el mensaje.

        switch (wmId) {
        case IDC_BUTTON_ACTIVATE_REMAP: {
            g_isRemapActive = !g_isRemapActive; // Alterna el estado activo/inactivo.
            if (g_isRemapActive) {
                keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, GetModuleHandle(NULL), 0);
                if (!keyboardHook) {
                    MessageBox(hwnd, L"Failed to install keyboard hook. Are you running as Administrator?", L"Hook Error", MB_ICONERROR);
                    g_isRemapActive = false; // Si falla, volvemos al estado original.
                    SetWindowText(g_hButtonActivate, g_strings[g_currentLanguage].activateRemap.c_str());
                }
                else {
                    SetWindowText(g_hButtonActivate, g_strings[g_currentLanguage].deactivateRemap.c_str());
                    SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].remappingActive.c_str());
                }
            }
            else {
                if (keyboardHook) {
                    UnhookWindowsHookEx(keyboardHook);
                    keyboardHook = NULL;
                }
                SetWindowText(g_hButtonActivate, g_strings[g_currentLanguage].activateRemap.c_str());
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].remappingInactive.c_str());
            }
            break;
        }

        case IDC_BUTTON_CHANGE_LANGUAGE: {
            // Cambiar idioma
            Language newLanguage = ShowLanguageDialog(hwnd);
            if (newLanguage != g_currentLanguage) {
                g_currentLanguage = newLanguage;
                SaveLanguagePreference();
                UpdateLanguageTexts();
            }
            break;
        }

        case IDC_BUTTON_SELECT_ORIGIN: {
            // Usamos la nueva ventana modal para seleccionar la tecla de origen
            DWORD vkCode = ShowKeySelectionWindow(hwnd, true);
            if (vkCode > 0) {
                g_tempOriginVkCode = vkCode;
                SetWindowText(g_hEditOrigin, GetKeyNameFromVkCode(g_tempOriginVkCode).c_str());
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].originSelected.c_str());
            }
            break;
        }

        case IDC_BUTTON_SELECT_DESTINY: {
            // Usamos la nueva ventana modal para seleccionar la tecla de destino
            DWORD vkCode = ShowKeySelectionWindow(hwnd, false);
            if (vkCode > 0) {
                g_tempDestinyVkCode = vkCode;
                SetWindowText(g_hEditDestiny, GetKeyNameFromVkCode(g_tempDestinyVkCode).c_str());
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].keysSelected.c_str());
            }
            break;
        }

        case IDC_BUTTON_ADD_REMAP: {
            if (g_tempOriginVkCode != 0 && g_tempDestinyVkCode != 0) {
                g_remapConfig[g_tempOriginVkCode] = g_tempDestinyVkCode;
                UpdateRemapList(g_hListRemapping);
                SaveRemapConfig();
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].remapAdded.c_str());

                // Limpia los campos para el siguiente remapeo.
                g_tempOriginVkCode = 0;
                g_tempDestinyVkCode = 0;
                SetWindowText(g_hEditOrigin, L"");
                SetWindowText(g_hEditDestiny, L"");
            }
            else {
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].selectRemapToRemove.c_str());
                MessageBox(hwnd, g_strings[g_currentLanguage].addRemapError.c_str(), L"Add Error", MB_ICONWARNING);
            }
            break;
        }

        case IDC_BUTTON_REMOVE_REMAP: {
            LRESULT selectedIndex = SendMessage(g_hListRemapping, LB_GETCURSEL, 0, 0);
            if (selectedIndex != LB_ERR) {
                if (!g_remapConfig.empty()) {
                    // Encuentra la tecla en el mapa bas�ndose en el �ndice de la lista.
                    auto it = g_remapConfig.begin();
                    advance(it, selectedIndex);
                    g_remapConfig.erase(it);
                    UpdateRemapList(g_hListRemapping);
                    SaveRemapConfig();
                    SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].remapRemoved.c_str());
                }
            }
            else {
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].selectRemapToRemove.c_str());
            }
            break;
        }

        case ID_TRAY_EXIT: {
            // Cerrar la aplicaci�n cuando se selecciona "Cerrar Programa" del men� contextual
            DestroyWindow(hwnd);
            break;
        }
        }
        break;
    }

    case WM_DESTROY: {
        // Elimina el icono de la bandeja si existe
        RemoveTrayIcon();

        // Cuando la ventana se cierra, desenganchamos el hook y salimos limpiamente.
        if (keyboardHook) {
            UnhookWindowsHookEx(keyboardHook);
            keyboardHook = NULL;
        }
        PostQuitMessage(0); // Env�a un mensaje para terminar el bucle principal.
        break;
    }

    case WM_SIZE: {
        if (wParam == SIZE_MINIMIZED) {
            // Cuando la ventana se minimiza, la ocultamos y mostramos el icono en la bandeja
            ShowWindow(hwnd, SW_HIDE);
            AddTrayIcon(hwnd);
        }
        break;
    }

    // A�adido para el soporte del icono en la bandeja del sistema
    case WM_TRAYICON: {
        if (lParam == WM_LBUTTONDBLCLK) {
            // Al hacer doble clic en el icono, restauramos la ventana
            ShowWindow(hwnd, SW_RESTORE);
            SetForegroundWindow(hwnd);
            RemoveTrayIcon();
        }
        else if (lParam == WM_RBUTTONUP) {
            // Al hacer clic derecho en el icono, mostramos el men� contextual
            POINT pt;
            GetCursorPos(&pt);
            ShowTrayMenu(hwnd, pt);
        }
        break;
    }

    default:
        // Para mensajes que no nos interesan, los pasamos al procedimiento por defecto de Windows.
        return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }
    return 0; // Mensaje procesado con �xito.
}