#pragma once

#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <shellapi.h>
#include <map>
#include <string>
#include <vector>
#include <cstdio>
#include <stdexcept>
#include <errno.h>

using namespace std;

// --- Control IDs ---
#define IDC_BUTTON_ACTIVATE_REMAP   1001
#define IDC_BUTTON_SELECT_ORIGIN    1002
#define IDC_EDIT_ORIGIN_KEY         1003
#define IDC_BUTTON_SELECT_DESTINY   1004
#define IDC_EDIT_DESTINY_KEY        1005
#define IDC_BUTTON_ADD_REMAP        1006
#define IDC_LIST_REMAPPING          1007
#define IDC_STATIC_STATUS           1008
#define IDC_BUTTON_REMOVE_REMAP     1009
#define IDI_TRAY_ICON               1010
#define WM_TRAYICON                 (WM_USER + 1)
#define IDC_BUTTON_CHANGE_LANGUAGE  1011

// --- Language Dialog IDs ---
#define IDD_LANGUAGE_DIALOG         2001
#define IDC_RADIO_SPANISH           2002
#define IDC_RADIO_ENGLISH           2003
#define IDC_BUTTON_LANGUAGE_OK      2004

// --- Tray Menu IDs ---
#define ID_TRAY_EXIT                3001

// --- Language Definition ---
enum Language {
    ENGLISH = 0,
    SPANISH = 1
};

// --- Global Variables (extern declarations) ---
extern HWND g_hMainWindow;
extern HWND g_hButtonActivate;
extern HWND g_hEditOrigin;
extern HWND g_hButtonSelectOrigin;
extern HWND g_hEditDestiny;
extern HWND g_hButtonSelectDestiny;
extern HWND g_hButtonAddRemap;
extern HWND g_hListRemapping;
extern HWND g_hStaticStatus;
extern HWND g_hButtonRemoveRemap;
extern HWND g_hButtonChangeLanguage;

extern bool g_isRemapActive;
extern HHOOK keyboardHook;
extern map<DWORD, DWORD> g_remapConfig;
extern bool g_isSelectingOrigin;
extern bool g_isSelectingDestiny;
extern DWORD g_tempOriginVkCode;
extern DWORD g_tempDestinyVkCode;

extern NOTIFYICONDATA g_nid;
extern HMENU g_hTrayMenu;

extern bool g_isSelectingModalOrigin;
extern DWORD g_modalKeySelected;
extern HWND g_modalKeyWindow;

extern HWND g_languageDialogWindow;
extern HWND g_radioSpanish;
extern HWND g_radioEnglish;
extern Language g_selectedLanguage;
extern Language g_currentLanguage;
extern bool g_isFirstRun;