#include "KeyUtils.h"
#include "Language.h"

wstring GetKeyNameFromVkCode(DWORD vkCode) {
    switch (vkCode) {
        // Botones del rat�n
    case VK_LBUTTON: return L"Left Mouse Button";
    case VK_RBUTTON: return L"Right Mouse Button";
    case VK_MBUTTON: return L"Middle Mouse Button";
    case VK_XBUTTON1: return L"X1 Mouse Button";
    case VK_XBUTTON2: return L"X2 Mouse Button";
        // Teclas especiales
    case VK_BACK: return L"BACKSPACE";
    case VK_TAB: return L"TAB";
    case VK_CLEAR: return L"CLEAR";
    case VK_RETURN: return L"ENTER";
    case VK_SHIFT: return L"SHIFT";
    case VK_CONTROL: return L"CTRL";
    case VK_MENU: return L"ALT";
    case VK_PAUSE: return L"PAUSE";
    case VK_CAPITAL: return L"CAPS LOCK";
    case VK_SPACE: return L"SPACEBAR";
    case VK_PRIOR: return L"PAGE UP";
    case VK_NEXT: return L"PAGE DOWN";
    case VK_END: return L"END";
    case VK_HOME: return L"HOME";
    case VK_LEFT: return L"LEFT ARROW";
    case VK_UP: return L"UP ARROW";
    case VK_RIGHT: return L"RIGHT ARROW";
    case VK_DOWN: return L"DOWN ARROW";
    case VK_SELECT: return L"SELECT";
    case VK_PRINT: return L"PRINT";
    case VK_EXECUTE: return L"EXECUTE";
    case VK_SNAPSHOT: return L"PRINT SCREEN";
    case VK_INSERT: return L"INS";
    case VK_DELETE: return L"DEL";
    case VK_HELP: return L"HELP";
        // N�meros (0-9)
    case '0': return L"0"; case '1': return L"1"; case '2': return L"2"; case '3': return L"3"; case '4': return L"4";
    case '5': return L"5"; case '6': return L"6"; case '7': return L"7"; case '8': return L"8"; case '9': return L"9";
        // Letras (A-Z)
    case 'A': return L"A"; case 'B': return L"B"; case L'C': return L"C"; case L'D': return L"D"; case L'E': return L"E";
    case 'F': return L"F"; case 'G': return L"G"; case L'H': return L"H"; case L'I': return L"I"; case L'J': return L"J";
    case 'K': return L"K"; case 'L': return L"L"; case L'M': return L"M"; case L'N': return L"N"; case L'O': return L"O";
    case 'P': return L"P"; case 'Q': return L"Q"; case L'R': return L"R"; case L'S': return L"S"; case L'T': return L"T";
    case 'U': return L"U"; case 'V': return L"V"; case L'W': return L"W"; case L'X': return L"X"; case L'Y': return L"Y";
    case 'Z': return L"Z";
        // Teclado num�rico
    case VK_NUMPAD0: return L"Num 0"; case VK_NUMPAD1: return L"Num 1"; case VK_NUMPAD2: return L"Num 2";
    case VK_NUMPAD3: return L"Num 3"; case VK_NUMPAD4: return L"Num 4"; case VK_NUMPAD5: return L"Num 5";
    case VK_NUMPAD6: return L"Num 6"; case VK_NUMPAD7: return L"Num 7"; case VK_NUMPAD8: return L"Num 8";
    case VK_NUMPAD9: return L"Num 9";
    case VK_MULTIPLY: return L"Num *"; case VK_ADD: return L"Num +"; case VK_SEPARATOR: return L"Num Separator";
    case VK_SUBTRACT: return L"Num -"; case VK_DECIMAL: return L"Num ."; case VK_DIVIDE: return L"Num /";
        // Teclas de Funci�n
    case VK_F1: return L"F1"; case VK_F2: return L"F2"; case VK_F3: return L"F3"; case VK_F4: return L"F4";
    case VK_F5: return L"F5"; case VK_F6: return L"F6"; case VK_F7: return L"F7"; case VK_F8: return L"F8";
    case VK_F9: return L"F9"; case VK_F10: return L"F10"; case VK_F11: return L"F11"; case VK_F12: return L"F12";
        // Teclas de Bloqueo
    case VK_NUMLOCK: return L"NUM LOCK";
    case VK_SCROLL: return L"SCROLL LOCK";
        // Modificadores Izquierda/Derecha
    case VK_LSHIFT: return L"Left SHIFT"; case VK_RSHIFT: return L"Right SHIFT";
    case VK_LCONTROL: return L"Left CTRL"; case VK_RCONTROL: return L"Right CTRL";
    case VK_LMENU: return L"Left ALT"; case VK_RMENU: return L"Right ALT";
        // Por defecto, intenta obtener el nombre del sistema o muestra el VK_CODE.
    default: {
        UINT scanCode = MapVirtualKey(vkCode, MAPVK_VK_TO_VSC);
        wchar_t keyName[256];
        if (GetKeyNameTextW(scanCode << 16, keyName, sizeof(keyName) / sizeof(keyName[0]))) {
            return keyName;
        }
        return L"VK_" + to_wstring(vkCode);
    }
    }
}

LRESULT CALLBACK KeySelectWindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        // Centra la ventana modal en la pantalla
        RECT rcParent;
        GetWindowRect(GetParent(hwnd), &rcParent);
        int width = 300;
        int height = 150;
        int x = rcParent.left + (rcParent.right - rcParent.left - width) / 2;
        int y = rcParent.top + (rcParent.bottom - rcParent.top - height) / 2;
        SetWindowPos(hwnd, NULL, x, y, width, height, SWP_NOZORDER);

        // Crea la etiqueta de instrucci�n
        CreateWindow(
            L"STATIC",
            g_isSelectingModalOrigin ?
            g_strings[g_currentLanguage].pressOriginKey.c_str() :
            g_strings[g_currentLanguage].pressDestinyKey.c_str(),
            WS_CHILD | WS_VISIBLE | SS_CENTER,
            10, 50, 280, 50,
            hwnd, NULL, GetModuleHandle(NULL), NULL
        );

        return 0;
    }

    case WM_KEYDOWN:
    case WM_SYSKEYDOWN: {
        // Captura el c�digo de tecla virtual
        g_modalKeySelected = (DWORD)wParam;
        // Cierra la ventana modal
        PostMessage(hwnd, WM_CLOSE, 0, 0);
        return 0;
    }

    case WM_CLOSE:
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        g_modalKeyWindow = NULL;
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

DWORD ShowKeySelectionWindow(HWND parentWindow, bool isOrigin) {
    static bool registered = false;

    // Registra la clase de ventana para la selecci�n de teclas
    if (!registered) {
        WNDCLASSEX wcex = { 0 };
        wcex.cbSize = sizeof(WNDCLASSEX);
        wcex.lpfnWndProc = KeySelectWindowProc;
        wcex.hInstance = GetModuleHandle(NULL);
        wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
        wcex.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
        wcex.lpszClassName = L"KeySelectWindowClass";

        if (!RegisterClassEx(&wcex)) {
            MessageBox(parentWindow, L"Error registering key selection window class", L"Error", MB_ICONERROR);
            return 0;
        }

        registered = true;
    }

    // Guarda el estado de selecci�n
    g_isSelectingModalOrigin = isOrigin;
    g_modalKeySelected = 0;

    // Crea la ventana modal
    g_modalKeyWindow = CreateWindowEx(
        WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
        L"KeySelectWindowClass",
        isOrigin ?
        g_strings[g_currentLanguage].originKeyTitle.c_str() :
        g_strings[g_currentLanguage].destinyKeyTitle.c_str(),
        WS_POPUP | WS_CAPTION | WS_SYSMENU,
        0, 0, 300, 150,
        parentWindow,
        NULL,
        GetModuleHandle(NULL),
        NULL
    );

    if (!g_modalKeyWindow) {
        MessageBox(parentWindow, L"Error creating key selection window", L"Error", MB_ICONERROR);
        return 0;
    }

    // Muestra la ventana y la hace modal
    ShowWindow(g_modalKeyWindow, SW_SHOW);
    EnableWindow(parentWindow, FALSE); // Deshabilita la ventana principal

    // Bucle de mensajes para la ventana modal
    MSG msg;
    while (g_modalKeyWindow && GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        if (!IsWindow(g_modalKeyWindow)) {
            // La ventana modal se ha cerrado
            break;
        }
    }

    // Vuelve a habilitar la ventana principal
    EnableWindow(parentWindow, TRUE);
    SetForegroundWindow(parentWindow);

    // Devuelve el c�digo de tecla seleccionado
    return g_modalKeySelected;
}