#include "Remapping.h"
#include "KeyUtils.h"
#include "Language.h"

void UpdateRemapList(HWND hListCtrl) {
    SendMessage(hListCtrl, LB_RESETCONTENT, 0, 0); // Limpia los elementos existentes.
    for (const auto& pair : g_remapConfig) {
        wstring s = L"Remap: " + GetKeyNameFromVkCode(pair.first) + L" -> " + GetKeyNameFromVkCode(pair.second);
        SendMessage(hListCtrl, LB_ADDSTRING, 0, (LPARAM)s.c_str());
    }
}

void LoadRemapConfig() {
    FILE* file = NULL;
    errno_t err = _wfopen_s(&file, L"remaps.txt", L"r"); // Usando _wfopen_s para mayor seguridad.
    if (err == 0 && file) { // Si no hay error y el archivo se abri�.
        wchar_t line[256];
        while (fgetws(line, sizeof(line) / sizeof(wchar_t), file)) {
            // Elimina saltos de l�nea.
            line[wcscspn(line, L"\n\r")] = 0;
            wstring sLine(line);
            size_t commaPos = sLine.find(L',');
            if (commaPos != wstring::npos) {
                try {
                    DWORD origin = stoul(sLine.substr(0, commaPos));
                    DWORD destiny = stoul(sLine.substr(commaPos + 1));
                    g_remapConfig[origin] = destiny;
                }
                catch (const std::exception& e) {
                    // Si hay un error al parsear una l�nea, lo ignoramos o lo logueamos.
                    // Para una app real, aqu� ir�a un logging m�s robusto.
                    MessageBoxA(NULL, e.what(), "Exception Caught", MB_ICONERROR);
                }
            }
        }
        fclose(file);
    }
}

void SaveRemapConfig() {
    FILE* file = NULL;
    errno_t err = _wfopen_s(&file, L"remaps.txt", L"w"); // Usando _wfopen_s para mayor seguridad.
    if (err == 0 && file) { // Si no hay error y el archivo se abri�.
        for (const auto& pair : g_remapConfig) {
            fwprintf(file, L"%lu,%lu\n", pair.first, pair.second);
        }
        fclose(file);
    }
    else {
        MessageBox(g_hMainWindow, L"Failed to save remapping configuration.", L"Save Error", MB_ICONERROR);
    }
}

LRESULT CALLBACK KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    // Si nCode es negativo, el mensaje no es para nosotros, lo pasamos al siguiente hook.
    if (nCode < 0) {
        return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
    }

    KBDLLHOOKSTRUCT* pKeyBoard = (KBDLLHOOKSTRUCT*)lParam;

    // L�gica para capturar la tecla Origen/Destino si estamos en modo de selecci�n.
    if (g_isSelectingOrigin || g_isSelectingDestiny) {
        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
            if (g_isSelectingOrigin) {
                g_tempOriginVkCode = pKeyBoard->vkCode;
                SetWindowText(g_hEditOrigin, GetKeyNameFromVkCode(g_tempOriginVkCode).c_str());
                g_isSelectingOrigin = false;
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].originSelected.c_str());

                // No desenganchamos el hook si el remapeo est� activo
                if (!g_isRemapActive && keyboardHook) {
                    UnhookWindowsHookEx(keyboardHook);
                    keyboardHook = NULL;
                }
            }
            else if (g_isSelectingDestiny) {
                g_tempDestinyVkCode = pKeyBoard->vkCode;
                SetWindowText(g_hEditDestiny, GetKeyNameFromVkCode(g_tempDestinyVkCode).c_str());
                g_isSelectingDestiny = false;
                SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].keysSelected.c_str());

                // No desenganchamos el hook si el remapeo est� activo
                if (!g_isRemapActive && keyboardHook) {
                    UnhookWindowsHookEx(keyboardHook);
                    keyboardHook = NULL;
                }
            }
            // Consumimos la pulsaci�n para que no interfiera mientras seleccionamos.
            return 1;
        }
    }

    // L�gica principal de remapeo si est� activo.
    if (g_isRemapActive) {
        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
            auto it = g_remapConfig.find(pKeyBoard->vkCode);
            if (it != g_remapConfig.end()) {
                // �Hemos encontrado un remapeo! Es hora de la transformaci�n.
                DWORD targetVkCode = it->second;

                // Suprime la pulsaci�n original. �Magia negra para el teclado!
                // NO LLAMES CallNextHookEx aqu�.

                // Simula la pulsaci�n de la tecla de destino.
                INPUT ip;
                ZeroMemory(&ip, sizeof(INPUT));
                ip.type = INPUT_KEYBOARD;
                ip.ki.wScan = 0;
                ip.ki.time = 0;
                ip.ki.dwExtraInfo = 0;

                // Pulsa la tecla de destino.
                ip.ki.wVk = static_cast<WORD>(targetVkCode); // Conversi�n controlada para evitar warnings.
                ip.ki.dwFlags = 0; // Tecla hacia abajo.
                SendInput(1, &ip, sizeof(INPUT));

                // Suelta la tecla de destino.
                ip.ki.dwFlags = KEYEVENTF_KEYUP; // Tecla hacia arriba.
                SendInput(1, &ip, sizeof(INPUT));

                return 1; // Bloquea el evento original para el sistema.
            }
        }
    }

    // Si no remapeamos, pasa el evento al siguiente hook.
    return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
}