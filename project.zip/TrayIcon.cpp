#include "TrayIcon.h"
#include "Language.h"

void CreateTrayMenu() {
    if (g_hTrayMenu) {
        DestroyMenu(g_hTrayMenu);
    }

    // Crea el men� contextual
    g_hTrayMenu = CreatePopupMenu();
    AppendMenu(g_hTrayMenu, MF_STRING, ID_TRAY_EXIT, g_strings[g_currentLanguage].closeProgram.c_str());
}

void ShowTrayMenu(HWND hwnd, POINT pt) {
    // Asegura que la ventana que cre� el men� est� en primer plano
    SetForegroundWindow(hwnd);

    // Muestra el men� contextual
    TrackPopupMenu(g_hTrayMenu, TPM_BOTTOMALIGN | TPM_LEFTALIGN,
        pt.x, pt.y, 0, hwnd, NULL);

    // Necesario para el correcto funcionamiento del men�
    PostMessage(hwnd, WM_NULL, 0, 0);
}

void AddTrayIcon(HWND hwnd) {
    // Inicializa la estructura NOTIFYICONDATA
    g_nid.cbSize = sizeof(NOTIFYICONDATA);
    g_nid.hWnd = hwnd;
    g_nid.uID = IDI_TRAY_ICON;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;

    // Crea el men� contextual
    CreateTrayMenu();

    // Carga el icono de la aplicaci�n o usa uno por defecto
    g_nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);

    // Establece el texto que aparece al pasar el cursor sobre el icono
    wcscpy_s(g_nid.szTip, g_strings[g_currentLanguage].windowTitle.c_str());

    // A�ade el icono a la bandeja
    Shell_NotifyIcon(NIM_ADD, &g_nid);
}

void RemoveTrayIcon() {
    Shell_NotifyIcon(NIM_DELETE, &g_nid);
}