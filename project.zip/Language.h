#pragma once

#include "Common.h"

// --- Translated Strings Structure ---
struct TranslatedStrings {
    wstring windowTitle;
    wstring activateRemap;
    wstring deactivateRemap;
    wstring originKey;
    wstring selectOrigin;
    wstring destinyKey;
    wstring selectDestiny;
    wstring addRemap;
    wstring removeSelected;
    wstring activeRemaps;
    wstring statusReady;
    wstring originSelected;
    wstring keysSelected;
    wstring addRemapError;
    wstring remapAdded;
    wstring remapRemoved;
    wstring selectRemapToRemove;
    wstring changeLanguage;
    wstring closeProgram;
    wstring remappingActive;
    wstring remappingInactive;
    wstring pressOriginKey;
    wstring pressDestinyKey;
    wstring originKeyTitle;
    wstring destinyKeyTitle;
    wstring selectLanguage;
    wstring spanish;
    wstring english;
    wstring ok;
};

// --- Global Language Data ---
extern TranslatedStrings g_strings[2];

// --- Language Management Functions ---
void LoadLanguagePreference();
void SaveLanguagePreference();
void UpdateLanguageTexts();
Language ShowLanguageDialog(HWND parentWindow);
LRESULT CALLBACK LanguageDialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);