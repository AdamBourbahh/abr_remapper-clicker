#include "Language.h"
#include "TrayIcon.h"
#include "Remapping.h"

// --- Translated Strings Definitions ---
TranslatedStrings g_strings[2] = {
    // ENGLISH
    {
        L"WinAPI Key Remapper",
        L"Activate Remap",
        L"Deactivate Remap",
        L"Origin Key:",
        L"Select Origin",
        L"Destiny Key:",
        L"Select Destiny",
        L"Add Remap",
        L"Remove Selected",
        L"Active Remaps:",
        L"Status: Ready",
        L"Origin key selected. Select destiny key or add remapping.",
        L"Keys selected. Click 'Add Remap'.",
        L"Please select both origin and destiny keys before adding the remap.",
        L"Remap added successfully. Another key tamed!",
        L"Remap removed. It was time to change the air!",
        L"Select a remap from the list to remove.",
        L"Change Language",
        L"Close Program",
        L"Remapping active. Your keyboard is no longer the same!",
        L"Remapping inactive. The keyboard returns to normal.",
        L"Press the key you want to use as ORIGIN",
        L"Press the key you want to use as DESTINY",
        L"ORIGIN key selection",
        L"DESTINY key selection",
        L"Select Language",
        L"Spanish",
        L"English",
        L"OK"
    },
    // SPANISH
    {
        L"WinAPI Remapeador de Teclas",
        L"Activar Remapeo",
        L"Desactivar Remapeo",
        L"Tecla Origen:",
        L"Seleccionar Origen",
        L"Tecla Destino:",
        L"Seleccionar Destino",
        L"A�adir Remapeo",
        L"Eliminar Seleccionado",
        L"Remapeos Activos:",
        L"Estado: Listo",
        L"Tecla origen seleccionada. Seleccione tecla destino o a�ada el remapeo.",
        L"Teclas seleccionadas. Haga clic en 'A�adir Remapeo'.",
        L"Por favor, seleccione tanto la tecla origen como destino antes de a�adir el remapeo.",
        L"Remapeo a�adido correctamente. �Otra tecla domada!",
        L"Remapeo eliminado. �Era hora de cambiar de aires!",
        L"Seleccione un remapeo de la lista para eliminar.",
        L"Cambiar Idioma",
        L"Cerrar Programa",
        L"Remapeo activo. �Tu teclado ya no es el mismo!",
        L"Remapeo inactivo. El teclado vuelve a la normalidad.",
        L"Presiona la tecla que quieres usar como ORIGEN",
        L"Presiona la tecla que quieres usar como DESTINO",
        L"Selecci�n de tecla ORIGEN",
        L"Selecci�n de tecla DESTINO",
        L"Selecciona el Idioma",
        L"Espa�ol",
        L"Ingl�s",
        L"Aceptar"
    }
};

// --- Language Management Functions ---

void LoadLanguagePreference() {
    FILE* file = NULL;
    errno_t err = _wfopen_s(&file, L"language.txt", L"r");
    if (err == 0 && file) {
        wchar_t line[10];
        if (fgetws(line, sizeof(line) / sizeof(wchar_t), file)) {
            line[wcscspn(line, L"\n\r")] = 0;
            wstring sLine(line);

            try {
                int lang = stoi(sLine);
                if (lang == SPANISH || lang == ENGLISH) {
                    g_currentLanguage = static_cast<Language>(lang);
                    g_isFirstRun = false;
                }
            }
            catch (const std::exception&) {
                // Error al convertir, usar el idioma predeterminado
                g_currentLanguage = ENGLISH;
                g_isFirstRun = true;
            }
        }
        fclose(file);
    }
    else {
        // Si no existe el archivo, es la primera ejecuci�n
        g_isFirstRun = true;
    }
}

void SaveLanguagePreference() {
    FILE* file = NULL;
    errno_t err = _wfopen_s(&file, L"language.txt", L"w");
    if (err == 0 && file) {
        fwprintf(file, L"%d\n", g_currentLanguage);
        fclose(file);
    }
}

void UpdateLanguageTexts() {
    if (g_hMainWindow) {
        // Actualiza el t�tulo de la ventana
        SetWindowText(g_hMainWindow, g_strings[g_currentLanguage].windowTitle.c_str());

        // Actualiza los textos de los controles
        SetWindowText(g_hButtonActivate, g_isRemapActive ?
            g_strings[g_currentLanguage].deactivateRemap.c_str() :
            g_strings[g_currentLanguage].activateRemap.c_str());

        // Actualiza textos est�ticos
        HWND hOriginStatic = GetDlgItem(g_hMainWindow, GetDlgCtrlID(g_hEditOrigin) - 1);
        if (hOriginStatic) {
            SetWindowText(hOriginStatic, g_strings[g_currentLanguage].originKey.c_str());
        }

        HWND hDestinyStatic = GetDlgItem(g_hMainWindow, GetDlgCtrlID(g_hEditDestiny) - 1);
        if (hDestinyStatic) {
            SetWindowText(hDestinyStatic, g_strings[g_currentLanguage].destinyKey.c_str());
        }

        HWND hRemapsStatic = GetDlgItem(g_hMainWindow, GetDlgCtrlID(g_hListRemapping) - 1);
        if (hRemapsStatic) {
            SetWindowText(hRemapsStatic, g_strings[g_currentLanguage].activeRemaps.c_str());
        }

        // Actualiza botones
        SetWindowText(g_hButtonSelectOrigin, g_strings[g_currentLanguage].selectOrigin.c_str());
        SetWindowText(g_hButtonSelectDestiny, g_strings[g_currentLanguage].selectDestiny.c_str());
        SetWindowText(g_hButtonAddRemap, g_strings[g_currentLanguage].addRemap.c_str());
        SetWindowText(g_hButtonRemoveRemap, g_strings[g_currentLanguage].removeSelected.c_str());
        SetWindowText(g_hButtonChangeLanguage, g_strings[g_currentLanguage].changeLanguage.c_str());

        // Actualiza texto de estado
        SetWindowText(g_hStaticStatus, g_strings[g_currentLanguage].statusReady.c_str());

        // Recrea el men� del icono de bandeja
        CreateTrayMenu();

        // Actualiza la lista de remapeos
        UpdateRemapList(g_hListRemapping);
    }
}

LRESULT CALLBACK LanguageDialogProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        // A�adir controles al di�logo
        g_radioSpanish = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].spanish.c_str(),
            WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | (g_currentLanguage == SPANISH ? WS_GROUP | BST_CHECKED : 0),
            50, 30, 150, 20,
            hwnd, (HMENU)IDC_RADIO_SPANISH, GetModuleHandle(NULL), NULL
        );

        g_radioEnglish = CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].english.c_str(),
            WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | (g_currentLanguage == ENGLISH ? WS_GROUP | BST_CHECKED : 0),
            50, 55, 150, 20,
            hwnd, (HMENU)IDC_RADIO_ENGLISH, GetModuleHandle(NULL), NULL
        );

        CreateWindow(
            L"BUTTON", g_strings[g_currentLanguage].ok.c_str(),
            WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
            75, 85, 100, 25,
            hwnd, (HMENU)IDOK, GetModuleHandle(NULL), NULL
        );

        return 0;
    }

    case WM_COMMAND: {
        switch (LOWORD(wParam)) {
        case IDOK: {
            // Detectar qu� idioma est� seleccionado
            if (SendMessage(g_radioSpanish, BM_GETCHECK, 0, 0) == BST_CHECKED) {
                g_selectedLanguage = SPANISH;
            }
            else {
                g_selectedLanguage = ENGLISH;
            }

            // Cerrar el di�logo
            DestroyWindow(hwnd);
            return 0;
        }
        }
        break;
    }

    case WM_CLOSE:
        // Si el usuario cierra el di�logo con X, mantener el idioma actual
        g_selectedLanguage = g_currentLanguage;
        DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        g_languageDialogWindow = NULL;
        return 0;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

Language ShowLanguageDialog(HWND parentWindow) {
    // Guardar el idioma actual como valor predeterminado
    g_selectedLanguage = g_currentLanguage;

    static bool languageDialogClassRegistered = false;

    // Registrar la clase de ventana para el di�logo de idioma si no est� registrada
    if (!languageDialogClassRegistered) {
        WNDCLASSEX wcex = { 0 };
        wcex.cbSize = sizeof(WNDCLASSEX);
        wcex.lpfnWndProc = LanguageDialogProc;
        wcex.hInstance = GetModuleHandle(NULL);
        wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
        wcex.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
        wcex.lpszClassName = L"LanguageDialogClass";

        if (!RegisterClassEx(&wcex)) {
            MessageBox(parentWindow, L"Error registering language dialog class", L"Error", MB_ICONERROR);
            return g_currentLanguage;
        }

        languageDialogClassRegistered = true;
    }

    // Crear el di�logo como una ventana modal
    g_languageDialogWindow = CreateWindowEx(
        WS_EX_DLGMODALFRAME | WS_EX_TOPMOST,
        L"LanguageDialogClass",
        g_strings[g_currentLanguage].selectLanguage.c_str(),
        WS_POPUP | WS_CAPTION | WS_SYSMENU,
        0, 0, 250, 150,
        parentWindow,
        NULL,
        GetModuleHandle(NULL),
        NULL
    );

    if (!g_languageDialogWindow) {
        MessageBox(parentWindow, L"Error creating language dialog", L"Error", MB_ICONERROR);
        return g_currentLanguage;
    }

    // Centrar el di�logo en la pantalla
    RECT rcParent;
    GetWindowRect(parentWindow, &rcParent);
    int width = 250;
    int height = 150;
    int x = rcParent.left + ((rcParent.right - rcParent.left) - width) / 2;
    int y = rcParent.top + ((rcParent.bottom - rcParent.top) - height) / 2;
    SetWindowPos(g_languageDialogWindow, NULL, x, y, width, height, SWP_NOZORDER);

    // Mostrar el di�logo
    EnableWindow(parentWindow, FALSE); // Deshabilitar ventana principal
    ShowWindow(g_languageDialogWindow, SW_SHOW);
    SetFocus(g_languageDialogWindow);

    // Bucle de mensajes para el di�logo
    MSG msg;
    while (g_languageDialogWindow && GetMessage(&msg, NULL, 0, 0)) {
        // Permitir que el di�logo procese sus propios mensajes
        if (!IsWindow(g_languageDialogWindow) || !IsDialogMessage(g_languageDialogWindow, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    // Re-habilitar la ventana principal
    EnableWindow(parentWindow, TRUE);
    SetForegroundWindow(parentWindow);

    // Devolver el idioma seleccionado
    return g_selectedLanguage;
}