#pragma once

#include "Common.h"

// --- Tray Icon Functions ---
void CreateTrayMenu();
void ShowTrayMenu(HWND hwnd, POINT pt);
void AddTrayIcon(HWND hwnd);
void RemoveTrayIcon();