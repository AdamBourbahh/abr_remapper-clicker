#include "Common.h"

// --- Global Variables Definitions ---
HWND g_hMainWindow = NULL;
HWND g_hButtonActivate = NULL;
HWND g_hEditOrigin = NULL;
HWND g_hButtonSelectOrigin = NULL;
HWND g_hEditDestiny = NULL;
HWND g_hButtonSelectDestiny = NULL;
HWND g_hButtonAddRemap = NULL;
HWND g_hListRemapping = NULL;
HWND g_hStaticStatus = NULL;
HWND g_hButtonRemoveRemap = NULL;
HWND g_hButtonChangeLanguage = NULL;

bool g_isRemapActive = false;
HHOOK keyboardHook = NULL;
map<DWORD, DWORD> g_remapConfig;
bool g_isSelectingOrigin = false;
bool g_isSelectingDestiny = false;
DWORD g_tempOriginVkCode = 0;
DWORD g_tempDestinyVkCode = 0;

NOTIFYICONDATA g_nid = { 0 };
HMENU g_hTrayMenu = NULL;

bool g_isSelectingModalOrigin = false;
DWORD g_modalKeySelected = 0;
HWND g_modalKeyWindow = NULL;

HWND g_languageDialogWindow = NULL;
HWND g_radioSpanish = NULL;
HWND g_radioEnglish = NULL;
Language g_selectedLanguage = ENGLISH;
Language g_currentLanguage = ENGLISH;
bool g_isFirstRun = true;